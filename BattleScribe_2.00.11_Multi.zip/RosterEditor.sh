#!/bin/sh
java -jar RosterEditor.jar
