#!/bin/sh
java -jar DataEditor.jar
