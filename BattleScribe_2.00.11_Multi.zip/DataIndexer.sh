#!/bin/sh
java -jar DataIndexer.jar
